include { FASTQC }       from '../modules/fastqc'
include { SEQKIT_STATS } from '../modules/seqkit_stats'
include { QC_SUMMARY }   from '../modules/qc_summary'
include { MULTIQC }      from '../modules/multiqc'


workflow QC {

    take:

    reads_ch


    main:

    /*
    ========================================================
    Detailed FastQC reports
    ========================================================
    */

    FASTQC(
        reads_ch
    )


    /*
    ========================================================
    Numerical FASTQ statistics

    Total reads
    Total bases
    Q20 %
    Q30 %
    GC %

    No filtering.
    ========================================================
    */

    SEQKIT_STATS(
        reads_ch
    )


    /*
    ========================================================
    Collect FastQC ZIP files for MultiQC
    ========================================================
    */

    fastqc_zips_ch =
        FASTQC.out.zip
            .map { meta, zip_files ->
                zip_files
            }
            .flatten()
            .collect()


    /*
    ========================================================
    Collect SeqKit statistics
    ========================================================
    */

    seqkit_stats_ch =
        SEQKIT_STATS.out.stats
            .map { meta, stats_file ->
                stats_file
            }
            .collect()


    /*
    ========================================================
    Combined QC table
    ========================================================
    */

    QC_SUMMARY(
        seqkit_stats_ch
    )


    /*
    ========================================================
    Combined FastQC report
    ========================================================
    */

    MULTIQC(
        fastqc_zips_ch
    )


    emit:

    fastqc_html =
        FASTQC.out.html

    fastqc_zip =
        FASTQC.out.zip

    seqkit_stats =
        SEQKIT_STATS.out.stats

    qc_summary =
        QC_SUMMARY.out.summary

    multiqc_report =
        MULTIQC.out.report

    multiqc_data =
        MULTIQC.out.data
}
