include { FASTQC }     from '../modules/fastqc'
include { QC_SUMMARY } from '../modules/qc_summary'
include { MULTIQC }    from '../modules/multiqc'


workflow QC {

    take:

    reads_ch


    main:

    FASTQC(
        reads_ch
    )


    fastqc_zips_ch =
        FASTQC.out.zip
            .map { meta, zip_files ->
                zip_files
            }
            .flatten()
            .collect()


    metadata_files_ch =
        FASTQC.out.metadata
            .map { meta, metadata_file ->
                metadata_file
            }
            .collect()


    QC_SUMMARY(
        fastqc_zips_ch,
        metadata_files_ch
    )


    MULTIQC(
        fastqc_zips_ch
    )


    emit:

    fastqc_html =
        FASTQC.out.html

    fastqc_zip =
        FASTQC.out.zip

    qc_summary =
        QC_SUMMARY.out.summary

    multiqc_report =
        MULTIQC.out.report

    multiqc_data =
        MULTIQC.out.data
}
